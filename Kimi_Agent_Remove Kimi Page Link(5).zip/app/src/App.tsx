import { useEffect, useRef, useState } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import {
  Waves,
  ChefHat,
  Zap,
  Heart,
  ShoppingBag,
  ArrowRight,
  Star,
  Quote,
  Menu,
  X,
  Instagram,
  Twitter,
  Facebook,
  Mail,
  Leaf,
  ShieldCheck,
  Timer,
  UtensilsCrossed,
} from "lucide-react";
import { Button } from "@/components/ui/button";

/* ─── Animation helpers ─── */
function FadeIn({
  children,
  delay = 0,
  direction = "up",
  className = "",
}: {
  children: React.ReactNode;
  delay?: number;
  direction?: "up" | "down" | "left" | "right";
  className?: string;
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });
  const directions = {
    up: { y: 40, x: 0 },
    down: { y: -40, x: 0 },
    left: { y: 0, x: 40 },
    right: { y: 0, x: -40 },
  };
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, ...directions[direction] }}
      animate={isInView ? { opacity: 1, x: 0, y: 0 } : {}}
      transition={{ duration: 0.7, delay, ease: [0.25, 0.1, 0.25, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ─── Navbar ─── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#FAF8F5]/90 backdrop-blur-md shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <nav className="flex items-center justify-between h-18 py-4">
          <a href="#" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-[#1E2A3A] rounded-full flex items-center justify-center group-hover:scale-105 transition-transform">
              <Waves className="w-5 h-5 text-[#FAF8F5]" />
            </div>
            <span className="text-xl font-bold tracking-tight text-[#1E2A3A]" style={{ fontFamily: "'Playfair Display', serif" }}>
              Fishwife
            </span>
          </a>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-8">
            {["Shop", "Our Story", "Sustainability", "Recipes"].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase().replace(/\s/g, "-")}`}
                className="text-sm font-medium text-[#4A5568] hover:text-[#1E2A3A] transition-colors relative after:absolute after:bottom-[-4px] after:left-0 after:h-[2px] after:w-0 hover:after:w-full after:bg-[#D4734A] after:transition-all"
              >
                {item}
              </a>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Button
              className="bg-[#1E2A3A] hover:bg-[#2D3E52] text-white rounded-full px-6 h-10 text-sm font-medium transition-all hover:shadow-lg hover:-translate-y-0.5"
            >
              Shop Best Sellers
            </Button>
          </div>

          {/* Mobile toggle */}
          <button
            className="md:hidden p-2 text-[#1E2A3A]"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </nav>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-[#FAF8F5] border-t border-[#E8E2D9] px-6 py-6 space-y-4"
        >
          {["Shop", "Our Story", "Sustainability", "Recipes"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(/\s/g, "-")}`}
              className="block text-base font-medium text-[#4A5568]"
              onClick={() => setMobileOpen(false)}
            >
              {item}
            </a>
          ))}
          <Button className="w-full bg-[#1E2A3A] hover:bg-[#2D3E52] text-white rounded-full h-11 text-sm font-medium">
            Shop Best Sellers
          </Button>
        </motion.div>
      )}
    </header>
  );
}

/* ─── Hero ─── */
function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section ref={ref} className="relative min-h-screen flex items-center overflow-hidden bg-[#FAF8F5]">
      <div className="absolute inset-0 z-0">
        <motion.img
          src="/hero-fish.jpg"
          alt="Premium tinned fish collection"
          className="w-full h-full object-cover opacity-90"
          style={{ y, scale: 1.1 }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#FAF8F5]/95 via-[#FAF8F5]/70 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 py-32">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-[#1E2A3A]/10 text-[#1E2A3A] rounded-full text-sm font-medium mb-8">
              <Star className="w-4 h-4 fill-[#D4734A] text-[#D4734A]" />
              Award-Winning Seafood
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-5xl md:text-7xl font-bold text-[#1E2A3A] leading-[1.1] mb-6 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Tinned Fish You’ll{" "}
            <span className="text-[#D4734A]">Actually Crave</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-lg md:text-xl text-[#4A5568] leading-relaxed mb-10 max-w-lg"
          >
            Sustainably sourced, chef-crafted seafood designed for flavor,
            convenience, and everyday luxury. Elevate your pantry staples.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="flex flex-wrap gap-4"
          >
            <Button className="bg-[#1E2A3A] hover:bg-[#2D3E52] text-white rounded-full px-8 h-14 text-base font-medium transition-all hover:shadow-xl hover:-translate-y-0.5 group">
              Shop Best Sellers
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              variant="outline"
              className="border-[#1E2A3A] text-[#1E2A3A] hover:bg-[#1E2A3A] hover:text-white rounded-full px-8 h-14 text-base font-medium transition-all"
            >
              Watch Our Story
            </Button>
          </motion.div>
        </div>
      </div>

      <motion.div
        style={{ opacity }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
      >
        <div className="w-6 h-10 border-2 border-[#1E2A3A]/30 rounded-full flex justify-center pt-2">
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-1.5 h-1.5 bg-[#1E2A3A]/50 rounded-full"
          />
        </div>
      </motion.div>
    </section>
  );
}

/* ─── Problem ─── */
function Problem() {
  const problems = [
    {
      title: "Bland & Uninspiring",
      desc: "Most canned fish tastes like a forgotten pantry relic—salty, mushy, and devoid of character.",
    },
    {
      title: "Questionable Sourcing",
      desc: "Opaque supply chains and industrial fishing practices that harm ocean ecosystems.",
    },
    {
      title: "No Culinary Joy",
      desc: "Eating it feels like a compromise, not a choice you'd proudly serve to guests.",
    },
  ];

  return (
    <section className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <FadeIn>
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-[#D4734A] tracking-widest uppercase mb-3 block">
              The Problem
            </span>
            <h2
              className="text-4xl md:text-5xl font-bold text-[#1E2A3A] mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Most canned fish is disappointing
            </h2>
            <p className="text-lg text-[#4A5568] max-w-2xl mx-auto">
              For decades, tinned seafood has been an afterthought. We think it
              deserves better.
            </p>
          </div>
        </FadeIn>

        <div className="grid md:grid-cols-3 gap-8">
          {problems.map((p, i) => (
            <FadeIn key={p.title} delay={i * 0.15}>
              <div className="p-8 bg-[#FAF8F5] rounded-2xl border border-[#E8E2D9] hover:border-[#D4734A]/30 hover:shadow-lg transition-all duration-300 group">
                <div className="w-12 h-12 bg-[#1E2A3A]/5 rounded-xl flex items-center justify-center mb-5 group-hover:bg-[#D4734A]/10 transition-colors">
                  <X className="w-6 h-6 text-[#1E2A3A]/60" />
                </div>
                <h3 className="text-xl font-bold text-[#1E2A3A] mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {p.title}
                </h3>
                <p className="text-[#4A5568] leading-relaxed">{p.desc}</p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Solution ─── */
function Solution() {
  return (
    <section id="our-story" className="py-24 md:py-32 bg-[#1E2A3A] relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4734A]/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-[#D4734A]/5 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <FadeIn direction="left">
            <div className="relative">
              <img
                src="/lifestyle-meal.jpg"
                alt="Beautifully plated smoked salmon"
                className="rounded-2xl shadow-2xl w-full object-cover aspect-[4/3]"
              />
              <div className="absolute -bottom-6 -right-6 bg-white rounded-xl p-5 shadow-xl max-w-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#D4734A]/10 rounded-full flex items-center justify-center">
                    <Heart className="w-5 h-5 text-[#D4734A]" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-[#1E2A3A]">12,000+ Happy Eaters</p>
                    <p className="text-xs text-[#4A5568]">And counting every day</p>
                  </div>
                </div>
              </div>
            </div>
          </FadeIn>

          <div>
            <FadeIn direction="right">
              <span className="text-sm font-semibold text-[#D4734A] tracking-widest uppercase mb-3 block">
                Our Solution
              </span>
              <h2
                className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                Meet Fishwife
              </h2>
              <p className="text-lg text-[#A0AEC0] leading-relaxed mb-8">
                We partner with sustainable fisheries and world-class chefs to
                create tinned seafood that rivals restaurant quality. Every can is
                a commitment to flavor, ethics, and the oceans we source from.
              </p>
            </FadeIn>

            <div className="space-y-5">
              {[
                { icon: Leaf, text: "100% sustainably sourced from MSC-certified fisheries" },
                { icon: ShieldCheck, text: "No artificial preservatives or additives" },
                { icon: UtensilsCrossed, text: "Developed with Michelin-trained chefs" },
              ].map((item, i) => (
                <FadeIn key={item.text} delay={0.2 + i * 0.1} direction="right">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-[#D4734A]/20 rounded-lg flex items-center justify-center shrink-0">
                      <item.icon className="w-5 h-5 text-[#D4734A]" />
                    </div>
                    <p className="text-[#CBD5E0] leading-relaxed pt-1.5">{item.text}</p>
                  </div>
                </FadeIn>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── Benefits ─── */
function Benefits() {
  const benefits = [
    {
      icon: Waves,
      title: "Sustainably Sourced",
      desc: "MSC-certified fisheries with full traceability from ocean to tin.",
    },
    {
      icon: ChefHat,
      title: "Chef-Crafted Recipes",
      desc: "Developed with Michelin-trained chefs for extraordinary flavor.",
    },
    {
      icon: Timer,
      title: "Ready in Minutes",
      desc: "Gourmet meals without the prep. Just open, plate, and enjoy.",
    },
    {
      icon: Zap,
      title: "High Protein Nutrition",
      desc: "25g+ protein per serving. Clean fuel for active lifestyles.",
    },
  ];

  return (
    <section id="sustainability" className="py-24 md:py-32 bg-[#FAF8F5]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <FadeIn>
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-[#D4734A] tracking-widest uppercase mb-3 block">
              Why Choose Us
            </span>
            <h2
              className="text-4xl md:text-5xl font-bold text-[#1E2A3A] mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Four Reasons to Make the Switch
            </h2>
          </div>
        </FadeIn>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((b, i) => (
            <FadeIn key={b.title} delay={i * 0.12}>
              <div className="bg-white p-8 rounded-2xl border border-[#E8E2D9] hover:border-[#D4734A]/30 hover:shadow-xl transition-all duration-300 group text-center h-full">
                <div className="w-16 h-16 bg-[#1E2A3A]/5 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-[#D4734A]/10 transition-colors">
                  <b.icon className="w-8 h-8 text-[#1E2A3A] group-hover:text-[#D4734A] transition-colors" />
                </div>
                <h3
                  className="text-xl font-bold text-[#1E2A3A] mb-3"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {b.title}
                </h3>
                <p className="text-[#4A5568] text-sm leading-relaxed">{b.desc}</p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Product ─── */
function Product() {
  const [selectedVariant, setSelectedVariant] = useState(0);
  const variants = [
    { name: "Classic", desc: "Traditional cold-smoked with oak wood", color: "#1E2A3A" },
    { name: "Peppered", desc: "Cracked black pepper crust", color: "#4A5568" },
    { name: "Dill & Lemon", desc: "Fresh herbs and citrus zest", color: "#D4734A" },
  ];

  return (
    <section id="shop" className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <FadeIn direction="left">
            <div className="relative">
              <div className="absolute -inset-4 bg-[#D4734A]/10 rounded-3xl blur-2xl" />
              <img
                src="/product-trio.jpg"
                alt="Smoked Salmon Trio"
                className="relative rounded-2xl shadow-xl w-full object-cover aspect-[3/4]"
              />
            </div>
          </FadeIn>

          <div>
            <FadeIn direction="right">
              <div className="flex items-center gap-2 mb-4">
                <span className="px-3 py-1 bg-[#D4734A]/10 text-[#D4734A] rounded-full text-xs font-semibold uppercase tracking-wider">
                  Best Seller
                </span>
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#D4734A] text-[#D4734A]" />
                  ))}
                  <span className="text-sm text-[#4A5568] ml-1">(847)</span>
                </div>
              </div>

              <h2
                className="text-4xl md:text-5xl font-bold text-[#1E2A3A] mb-4"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                Smoked Salmon Trio
              </h2>
              <p className="text-lg text-[#4A5568] leading-relaxed mb-8">
                Rich, smoky, and perfectly preserved. Three distinct flavor
                profiles crafted from wild-caught Alaskan salmon. Each tin is a
                complete culinary experience waiting to be opened.
              </p>

              <div className="flex gap-3 mb-8">
                {variants.map((v, i) => (
                  <button
                    key={v.name}
                    onClick={() => setSelectedVariant(i)}
                    className={`px-5 py-3 rounded-xl text-sm font-medium transition-all border ${
                      selectedVariant === i
                        ? "border-[#D4734A] bg-[#D4734A]/10 text-[#1E2A3A]"
                        : "border-[#E8E2D9] bg-white text-[#4A5568] hover:border-[#1E2A3A]/30"
                    }`}
                  >
                    {v.name}
                  </button>
                ))}
              </div>

              <p className="text-sm text-[#4A5568] mb-8">
                {variants[selectedVariant].desc}
              </p>

              <div className="flex items-center gap-6 mb-8">
                <span className="text-3xl font-bold text-[#1E2A3A]">$48.00</span>
                <span className="text-lg text-[#4A5568] line-through">$60.00</span>
                <span className="px-3 py-1 bg-[#D4734A]/10 text-[#D4734A] rounded-full text-xs font-semibold">
                  Save 20%
                </span>
              </div>

              <div className="flex gap-4">
                <Button className="bg-[#1E2A3A] hover:bg-[#2D3E52] text-white rounded-full px-8 h-14 text-base font-medium transition-all hover:shadow-xl hover:-translate-y-0.5 flex-1">
                  <ShoppingBag className="w-5 h-5 mr-2" />
                  Add to Cart
                </Button>
                <Button
                  variant="outline"
                  className="border-[#E8E2D9] hover:border-[#1E2A3A] rounded-full w-14 h-14 p-0"
                >
                  <Heart className="w-5 h-5" />
                </Button>
              </div>
            </FadeIn>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── Social Proof / Testimonials ─── */
function Testimonials() {
  const testimonials = [
    {
      text: "I never thought canned fish could taste this good. Fishwife has completely changed how I think about pantry meals.",
      author: "Sarah M.",
      role: "Home Chef & Food Blogger",
    },
    {
      text: "The quality is insane. I serve this to dinner party guests and they always ask where I got it. It's become my secret weapon.",
      author: "James L.",
      role: "Restaurant Owner",
    },
    {
      text: "Finally, tinned fish with ethics AND flavor. The traceability gives me peace of mind, the taste keeps me coming back.",
      author: "Priya K.",
      role: "Sustainability Advocate",
    },
  ];

  return (
    <section className="py-24 md:py-32 bg-[#FAF8F5]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <FadeIn>
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-[#D4734A] tracking-widest uppercase mb-3 block">
              Reviews
            </span>
            <h2
              className="text-4xl md:text-5xl font-bold text-[#1E2A3A] mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              People Are Obsessed
            </h2>
          </div>
        </FadeIn>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <FadeIn key={t.author} delay={i * 0.15}>
              <div className="bg-white p-8 rounded-2xl border border-[#E8E2D9] hover:shadow-lg transition-all duration-300 relative">
                <Quote className="w-10 h-10 text-[#D4734A]/20 absolute top-6 right-6" />
                <div className="flex gap-1 mb-5">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-[#D4734A] text-[#D4734A]" />
                  ))}
                </div>
                <p className="text-[#1E2A3A] leading-relaxed mb-6 italic text-lg">
                  "{t.text}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#1E2A3A]/10 rounded-full flex items-center justify-center text-sm font-bold text-[#1E2A3A]">
                    {t.author[0]}
                  </div>
                  <div>
                    <p className="font-semibold text-[#1E2A3A] text-sm">{t.author}</p>
                    <p className="text-xs text-[#4A5568]">{t.role}</p>
                  </div>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Newsletter ─── */
function Newsletter() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  return (
    <section className="py-24 md:py-32 bg-white">
      <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center">
        <FadeIn>
          <h2
            className="text-4xl md:text-5xl font-bold text-[#1E2A3A] mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Join the Fishwife Family
          </h2>
          <p className="text-lg text-[#4A5568] mb-10">
            Get exclusive recipes, early access to new releases, and 15% off your
            first order.
          </p>
        </FadeIn>

        <FadeIn delay={0.2}>
          {submitted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-[#D4734A]/10 rounded-2xl p-8"
            >
              <div className="w-12 h-12 bg-[#D4734A]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-6 h-6 text-[#D4734A]" />
              </div>
              <h3 className="text-xl font-bold text-[#1E2A3A] mb-2">Welcome Aboard!</h3>
              <p className="text-[#4A5568]">Check your inbox for your discount code.</p>
            </motion.div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (email) setSubmitted(true);
              }}
              className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            >
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 px-6 py-4 bg-[#FAF8F5] border border-[#E8E2D9] rounded-full text-[#1E2A3A] placeholder:text-[#4A5568]/50 focus:outline-none focus:border-[#D4734A] transition-colors"
                required
              />
              <Button
                type="submit"
                className="bg-[#1E2A3A] hover:bg-[#2D3E52] text-white rounded-full px-8 h-14 text-base font-medium transition-all hover:shadow-lg"
              >
                Subscribe
              </Button>
            </form>
          )}
        </FadeIn>
      </div>
    </section>
  );
}

/* ─── Final CTA ─── */
function FinalCTA() {
  return (
    <section className="py-24 md:py-32 bg-[#1E2A3A] relative overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="/hero-fish.jpg"
          alt=""
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-[#1E2A3A]/80" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 lg:px-8 text-center">
        <FadeIn>
          <h2
            className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Upgrade Your Pantry Today
          </h2>
          <p className="text-lg md:text-xl text-[#A0AEC0] mb-10 max-w-2xl mx-auto">
            Join thousands who've discovered that tinned fish can be
            extraordinary. Free shipping on orders over $50.
          </p>
          <Button className="bg-[#D4734A] hover:bg-[#B85F3C] text-white rounded-full px-10 h-16 text-lg font-medium transition-all hover:shadow-xl hover:-translate-y-0.5 group">
            Shop Now
            <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </FadeIn>
      </div>
    </section>
  );
}

/* ─── Footer ─── */
function Footer() {
  return (
    <footer className="bg-[#FAF8F5] border-t border-[#E8E2D9] py-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-[#1E2A3A] rounded-full flex items-center justify-center">
                <Waves className="w-5 h-5 text-[#FAF8F5]" />
              </div>
              <span className="text-xl font-bold text-[#1E2A3A]" style={{ fontFamily: "'Playfair Display', serif" }}>
                Fishwife
              </span>
            </div>
            <p className="text-sm text-[#4A5568] leading-relaxed mb-4">
              Premium, responsibly sourced seafood that transforms everyday meals
              into something special.
            </p>
            <div className="flex gap-3">
              {[Instagram, Twitter, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 bg-[#1E2A3A]/5 rounded-full flex items-center justify-center hover:bg-[#D4734A]/20 hover:text-[#D4734A] transition-colors text-[#4A5568]"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold text-[#1E2A3A] mb-4 text-sm uppercase tracking-wider">
              Shop
            </h4>
            <ul className="space-y-3">
              {["Best Sellers", "Smoked Salmon", "Tuna", "Sardines", "Gift Sets"].map(
                (item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="text-sm text-[#4A5568] hover:text-[#D4734A] transition-colors"
                    >
                      {item}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-[#1E2A3A] mb-4 text-sm uppercase tracking-wider">
              Company
            </h4>
            <ul className="space-y-3">
              {["Our Story", "Sustainability", "Recipes", "Press", "Careers"].map(
                (item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="text-sm text-[#4A5568] hover:text-[#D4734A] transition-colors"
                    >
                      {item}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-[#1E2A3A] mb-4 text-sm uppercase tracking-wider">
              Support
            </h4>
            <ul className="space-y-3">
              {["Contact Us", "Shipping & Returns", "FAQ", "Privacy Policy", "Terms"].map(
                (item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="text-sm text-[#4A5568] hover:text-[#D4734A] transition-colors"
                    >
                      {item}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>
        </div>

        <div className="border-t border-[#E8E2D9] pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-[#4A5568]">
            © 2025 Fishwife. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-sm text-[#4A5568]">
            <Mail className="w-4 h-4" />
            <a href="mailto:hello@fishwife.com" className="hover:text-[#D4734A] transition-colors">
              hello@fishwife.com
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ─── Main App ─── */
export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#1E2A3A]">
      <Navbar />
      <Hero />
      <Problem />
      <Solution />
      <Benefits />
      <Product />
      <Testimonials />
      <Newsletter />
      <FinalCTA />
      <Footer />
    </div>
  );
}
